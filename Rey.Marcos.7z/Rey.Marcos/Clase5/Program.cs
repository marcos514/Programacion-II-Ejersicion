﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase05;
namespace Clase5
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tinta1=new Tinta();
            Tinta tinta2 = new Tinta(ConsoleColor.Red);
            Tinta tinta3 = new Tinta(ETipoTinta.China);
            Tinta tinta4 = new Tinta(ConsoleColor.Black, ETipoTinta.China);

            Console.WriteLine((string)tinta1);
            Console.ReadLine();
            Console.WriteLine(tinta2);
            Console.ReadLine();
            Console.WriteLine(tinta3);
            Console.ReadLine();
            Console.WriteLine(tinta4);
            Console.ReadLine();

            Console.WriteLine(tinta1 != tinta2);
            Console.ReadLine();
            Console.WriteLine(tinta3 != tinta4);
            Console.ReadLine();

        }
    }
}
