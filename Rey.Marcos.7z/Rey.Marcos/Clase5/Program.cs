﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase05;
namespace Clase5
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tinta1=new Tinta();
            Tinta tinta2 = new Tinta(ConsoleColor.Blue);
            Tinta tinta3 = new Tinta(ConsoleColor.Cyan,ETipoTinta.China);
            Tinta tinta4 = new Tinta(ConsoleColor.Black, ETipoTinta.ConBrillito);
            Pluma plumaRoja = new Pluma(99, "Mapet", tinta4);
            Pluma plumaNegra = new Pluma(1, "Mapet", tinta1);
            Pluma plumaAzul = new Pluma(2, "Mapet", tinta2);
            Pluma plumaCyan = new Pluma(50, "Mapet", tinta3);

            Console.WriteLine(plumaRoja);
            Console.ReadLine();
            Console.WriteLine(plumaNegra);
            Console.ReadLine();
            Console.WriteLine(plumaAzul);
            Console.ReadLine();
            Console.WriteLine(plumaCyan);
            Console.ReadLine();

            plumaRoja = plumaRoja + tinta4;
            plumaRoja = plumaRoja + tinta4;
            plumaNegra = plumaNegra - tinta1;
            plumaNegra = plumaNegra - tinta1;
            Console.WriteLine(plumaRoja);
            Console.ReadLine();
            Console.WriteLine(plumaNegra);
            Console.ReadLine();

            Console.WriteLine(plumaNegra == tinta4);
            Console.ReadLine();
            

        }
    }
}
