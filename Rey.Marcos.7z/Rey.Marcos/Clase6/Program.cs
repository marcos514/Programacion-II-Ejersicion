﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase06.Entidades;


namespace Clase6
{
    class Program
    {
        static void Main(string[] args)
        {
            Tempera tempera1=new Tempera(ConsoleColor.Red,"Hola",10);
            Tempera tempera2 = new Tempera(ConsoleColor.White, "Filgo", 100);
            
            Console.WriteLine(Tempera.Mostrar(tempera1));
            Console.WriteLine();

            Console.WriteLine(Tempera.Mostrar(tempera1+20));
            Console.WriteLine();

            Console.WriteLine(tempera1 == tempera1);
            Console.WriteLine();

            Console.WriteLine(tempera1 == tempera2);
            Console.WriteLine();
            
            Console.WriteLine(Tempera.Mostrar(tempera2));
            Console.WriteLine();

            Console.WriteLine(Tempera.Mostrar(tempera2+100));
            Console.WriteLine();

            Console.WriteLine(tempera1+10);
            Console.WriteLine(tempera1);

            Console.ReadLine();

            Paleta paleta1=10;
            
        }
    }
}
