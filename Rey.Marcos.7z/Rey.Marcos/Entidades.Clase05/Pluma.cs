﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase05
{
    public class Pluma
    {
        private string _Marca;
        private Tinta _Tinta;
        private int cantidad;

        public Pluma()
        {
            this._Marca = "Sin marca";
            this._Tinta = null;
            this.cantidad = 0;
        }

        public Pluma(int cantidad):this()
        {
            this.cantidad = cantidad;
        }

        public Pluma(string marca):this()
        {
            this._Marca = marca;
        }

        public Pluma(Tinta tinta):this()
        {
            this._Tinta = tinta;
        }

        public Pluma(int cantidad,string marca): this(cantidad)
        {
            this._Marca = marca;
        }

        public Pluma(int cantidad, Tinta tinta): this(cantidad)
        {
            this._Tinta = tinta;
        }

        public Pluma(int cantidad, string marca,Tinta tinta): this(cantidad,marca)
        {
            this._Tinta = tinta;
        }
        public Pluma(string marca, Tinta tinta) : this(marca)
        {
            this._Tinta = tinta;
        }


        private string Mostrar()
        {
            return "Marca: " + this._Marca + "\nCantidad: " + this.cantidad + "\nTinta: " + Tinta.Mostrar(this._Tinta);
        }

        
        public static bool operator ==(Pluma pluma, Tinta tinta)
        {
            return (pluma._Tinta == tinta);
        }

        public static bool operator !=(Pluma pluma, Tinta tinta)
        {
            return !(pluma==tinta);
        }


        public static Pluma operator +(Pluma pluma, Tinta tinta)
        {
            if (pluma == tinta && pluma.cantidad<100)
            {
                pluma.cantidad++;
            }
            return pluma;
        }

        public static Pluma operator -(Pluma pluma, Tinta tinta)
        {
            if (pluma == tinta && pluma.cantidad > 0)
            {
                pluma.cantidad--;
            }
            return pluma;
        }

        public static implicit operator string(Pluma pluma)
        {
            return pluma.Mostrar();
        }


    }
}
