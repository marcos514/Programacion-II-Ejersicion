﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase05
{
    public class Tinta
    {
        private ConsoleColor _Color;
        private ETipoTinta _Tipo;

        //Comienzo constructores
        public Tinta()
        {
            this._Color = ConsoleColor.Black;
            this._Tipo = ETipoTinta.Comun;
        }

        public Tinta(ConsoleColor color): this()
        {
            this._Color = color;
        }

        public Tinta(ETipoTinta tinta) : this()
        {
            this._Tipo = tinta;
        }

        public Tinta(ConsoleColor color,ETipoTinta tinta) : this(color)
        {
            this._Tipo = tinta;
        }
        //Fin constructores

        //Comienzo Mostrar
        private string Mostrar()
        {
            return "Color: " + this._Color + "\nTipo de tinta: " + this._Tipo;
        }

        public static string Mostrar(Tinta tinta)
        {
            return tinta.Mostrar();
        }
        //Fin Mostrar
        public static bool operator ==(Tinta tinta1, Tinta tinta2)
        {
              return (tinta1._Color == tinta2._Color) && (tinta1._Tipo == tinta2._Tipo);
        }

        public static bool operator !=(Tinta tinta1, Tinta tinta2)
        {
            return !(tinta1 == tinta2);
            
        }

        public static explicit operator string(Tinta tinta1)
        {
            return tinta1.Mostrar();
        }

        /*public static implicit operator string(Tinta tinta1)
        {
            return tinta1.Mostrar();
        }*/

        //Empieza Sobrecarga
        

    }
}
