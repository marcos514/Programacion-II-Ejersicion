﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.Entidades
{
    public class Paleta
    {
        private Tempera[] _temperas;
        private int _cantidadColores;

        //constructor
        private Paleta(int cantidad)
        {
            this._cantidadColores = cantidad;
            this._temperas = new Tempera[this._cantidadColores];
        }

        private Paleta():this(5)
        { 

        }

        public static implicit operator Paleta(int cantidad)
        {
            return new Paleta(cantidad);
        }

        //metodo
        private string Mostrar()
        {
            return "Cantidad maxima de elementos: " +this._cantidadColores+ (string)this;
        }

        public static explicit operator string(Paleta paleta)
        { 
            string devolver="";
            foreach (Tempera aux in paleta._temperas)
            {
                devolver += Tempera.Mostrar(aux);
            }

            return devolver;
        }





    }
}
