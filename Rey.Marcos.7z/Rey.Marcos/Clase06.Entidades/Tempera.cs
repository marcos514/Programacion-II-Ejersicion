﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.Entidades
{
    public class Tempera
    {
        private ConsoleColor _color;
        private string _marca;
        private int _cantidad;
        //constructor
        public Tempera(ConsoleColor color, string marca, int cantidad)
        {
            this._cantidad = cantidad;
            this._color = color;
            this._marca = marca;
        }

        //metodos
        string Mostrar()
        {
            return "Color: " + this._color + "\nMarca: " + this._marca + "\nCantidad: " + this._cantidad + "\n\n";
        }

        static public string Mostrar(Tempera tempera)
        {
            return tempera.Mostrar();
        }

        public static bool operator ==(Tempera tempera1, Tempera tempera2)
        {
            return (tempera1._color == tempera2._color) && (tempera1._marca == tempera2._marca);
        }

        public static bool operator !=(Tempera tempera1, Tempera tempera2)
        {
            return ! (tempera1 == tempera2);
        }

        public static  Tempera operator +(Tempera tempera, double incremento)
        {
            Tempera temperaAux = new Tempera(tempera._color, tempera._marca, tempera._cantidad);
            if (incremento >= 0 && tempera._cantidad + (int)incremento <= 100)
            {
    
                temperaAux._cantidad+= (int)incremento;
                
            }
           
            return temperaAux;
        }

        public static implicit operator int(Tempera tempera)
        {
            return tempera._cantidad;
        }
        

    }
}
