﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase4
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
            Cosa nuevaCosa = new Cosa(15, "Marcos el mejor");
            nuevaCosa.EstablecerValor(ConsoleColor.White);

            Console.Write(nuevaCosa.Mostrar());
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine();
            nuevaCosa.EstablecerValor(18, "Marcos Rey", new DateTime(1988, 10, 1));
            nuevaCosa.EstablecerValor(ConsoleColor.DarkGray);
            Console.Write(nuevaCosa.Mostrar());
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.ReadLine();
        }
    }
}
