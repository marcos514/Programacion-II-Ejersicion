﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase4
{
    class Cosa
    {
        public int entero;
        public string  cadena;
        public DateTime fecha;
        public ConsoleColor color;


        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="numero"> Entero que se guardara en el atributo entero</param>
        public void EstablecerValor(int numero)
        {
            this.entero = numero;
        }

        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="cadena">String que se guardara en el atributo cadena</param>
        public void EstablecerValor(string cadena)
        {
            this.cadena = cadena;
        }


        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="dia">DateTime que se guardara en el atributo fecha</param>
        public void EstablecerValor(DateTime dia)
        {
            this.fecha = dia;
        }


        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="numero">Entero que se guardara en el atributo entero</param>
        /// <param name="cadena">String que se guardara en el atributo cadena</param>
        public void EstablecerValor(int numero, string cadena)
        {
            this.EstablecerValor(numero);
            this.EstablecerValor(cadena);
        }

        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="numero">Entero que se guardara en el atributo entero</param>
        /// <param name="dia">DateTime que se guardara en el atributo fecha</param>
        public void EstablecerValor(int numero, DateTime dia)
        {
            this.EstablecerValor(numero);
            this.EstablecerValor(dia);
        }


        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="numero">Entero que se guardara en el atributo entero</param>
        /// <param name="cadena">String que se guardara en el atributo cadena</param>
        /// <param name="dia">DateTime que se guardara en el atributo fecha</param>
        public void EstablecerValor(int numero, string cadena, DateTime dia)
        {
            this.EstablecerValor(numero);
            this.EstablecerValor(cadena);
            this.EstablecerValor(dia);
        }


        /// <summary>
        /// Setea en el objeto
        /// </summary>
        /// <param name="cadena">String que se guardara en el atributo cadena</param>
        /// <param name="dia">DateTime que se guardara en el atributo fecha</param>
        public void EstablecerValor(string cadena, DateTime dia)
        {
            this.EstablecerValor(cadena);
            this.EstablecerValor(dia);
        }

        public void EstablecerValor(ConsoleColor color)
        {
            this.color = color;
        }


        /// <summary>
        /// Unifica los datos del objeto
        /// </summary>
        /// <returns>Sring que muestra cada atributo diciendop que es </returns>
        public string Mostrar()
        {
            Console.ForegroundColor = this.color;
            return "Numero entero: " + this.entero + "\nLa cadena es: " + this.cadena + "\nLa fecha es: " + this.fecha + "\nColor: " + this.color;
        }


        //Constructor

        /// <summary>
        /// Inicaliza los atributos
        /// </summary>
        public Cosa()
        {
            this.EstablecerValor(0,"Sin Valor",DateTime.Now);
        }


        /// <summary>
        /// Inicaliza los atributos 
        /// </summary>
        /// <param name="numero">Setea el valor en el atributo entero </param>
        public Cosa(int numero):this()
        {
            this.EstablecerValor(numero);
        }


        /// <summary>
        /// Inicaliza los atributos 
        /// </summary>
        /// <param name="cadena">Setea el valor en el atributo cadena</param>
        public Cosa(string cadena):this()
        {
            this.EstablecerValor(cadena);
        }


        /// <summary>
        /// Inicaliza los atributos
        /// </summary>
        /// <param name="dia">Setea el valor en el atributo fecha</param>
        public Cosa(DateTime dia):this()
        {
            this.EstablecerValor(dia);
        }


        /// <summary>
        /// Inicaliza los atributos
        /// </summary>
        /// <param name="numero">Setea el valor en el atributo entero</param>
        /// <param name="cadena">Setea el valor en el atributo cadena</param>
        /// <param name="dia">Setea el valor en el atributo fecha</param>
        public Cosa(int numero, string cadena, DateTime dia): this()
        {
            this.EstablecerValor(numero, cadena, dia);
        }


        /// <summary>
        /// Inicaliza los atributos
        /// </summary>
        /// <param name="numero">Setea el valor en el atributo entero</param>
        /// <param name="cadena">Setea el valor en el atributo cadena</param>
        public Cosa(int numero, string cadena): this()
        {
            this.EstablecerValor(numero, cadena);
        }


        /// <summary>
        ///  Inicaliza los atributos
        /// </summary>
        /// <param name="numero"Setea el valor en el atributo entero></param>
        /// <param name="dia">Setea el valor en el atributo fecha</param>
        public Cosa(int numero, DateTime dia):this()
        {
            this.EstablecerValor(numero, dia);
        }


        /// <summary>
        /// Inicaliza los atributos
        /// </summary>
        /// <param name="cadena">Setea el valor en el atributo cadena</param>
        /// <param name="dia">Setea el valor en el atributo fecha</param>
        public Cosa(string cadena, DateTime dia):this()
        {
            this.EstablecerValor(cadena, dia);
        }

    }
}
