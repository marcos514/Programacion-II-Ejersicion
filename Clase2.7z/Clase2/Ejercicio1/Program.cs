﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{ 

    class Program
    {   
        static void Main(string[] args)
        {
            Persona alumno = new Persona();

            Persona.Saludar();
            Console.ReadLine();
            
            alumno.Saludar2();
            Console.ReadLine();

        }
    }
}
