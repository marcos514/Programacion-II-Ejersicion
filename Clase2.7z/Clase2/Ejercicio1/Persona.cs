﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Persona
    {
        public static void Saludar()
        {
            Console.WriteLine("Hola");
        }

        public void Saludar2()
        {
            Console.WriteLine("Hola Hola");
        }
    }
}
