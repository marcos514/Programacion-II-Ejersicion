﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Conversor
    {
        public static double BinarioDecimal(string NumeroBinario)
        {
            return BitConverter.Int64BitsToDouble(Convert.ToInt64(NumeroBinario, 2));
        }

        public static string DecimalBinario(double numeroDecimal)
        {
            return Convert.ToString(BitConverter.DoubleToInt64Bits(numeroDecimal), 2);
        }

    }
}
