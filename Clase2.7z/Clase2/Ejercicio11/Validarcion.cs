﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    class Validacion
    {
        public static bool Validar(int numeroIngresado, int rangoMinimo, int rangoMaximo)
        {
            return numeroIngresado >= rangoMinimo && numeroIngresado <= rangoMaximo;
        }
    }
}
