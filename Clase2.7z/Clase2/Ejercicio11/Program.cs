﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int maximo = 0;
            int minimo = 0;
            float promedio = 0;
            int contador;
            byte bandera = 0;
            for (contador = 0; contador < 10; contador++)
            {
                Console.Clear();
                Console.WriteLine("Ingrese un numero entre -100 y 100");
                while (!int.TryParse(Console.ReadLine(), out numero) || !Validacion.Validar(numero, -100, 100))
                {
                    Console.Clear();
                    Console.WriteLine("Error Ingrese un numero entre -100 y 100");
                }
                if (bandera == 0)
                {
                    maximo = numero;
                    minimo = numero;
                    bandera++;

                }
                else if (numero > maximo)
                {
                    maximo = numero;
                }
                else if (numero < minimo)
                {
                    minimo = numero;
                }
                promedio += numero;

            }
            promedio /= contador;
            Console.WriteLine("Numero minimo: " + minimo);
            Console.WriteLine("Numero Maximo: " + maximo);
            Console.WriteLine("Promedio: " + promedio);
            Console.ReadLine();



        }
    }
}

