﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio14
{
    class Program
    {
        static void Main(string[] args)
        {
            int primerNumero;
            int segundoNumero;

            Console.Write("Ingrese el lado del cuadrado: ");
            while (!int.TryParse(Console.ReadLine(), out primerNumero) || primerNumero <= 0)
            {
                Console.Clear();
                Console.Write("Error Ingrese el lado del cuadrado: ");
            }
            Console.Clear();
            Console.Write( CalculoArea.CalcularCuadrado(primerNumero));
            Console.ReadLine();


            Console.Write("Ingrese la base del triangulo: ");
            while (!int.TryParse(Console.ReadLine(), out primerNumero) || primerNumero <= 0)
            {
                Console.Clear();
                Console.Write("Error Ingrese la base del triangulo: ");
            }
            Console.Write("Ingrese la altura del triangulo: ");
            while (!int.TryParse(Console.ReadLine(), out segundoNumero) || segundoNumero <= 0)
            {
                Console.Clear();
                Console.Write("Error Ingrese la altura del triangulo: ");
            }
            Console.Clear();
            Console.Write(CalculoArea.CalcularTriangulo(primerNumero,segundoNumero));
            Console.ReadLine();


            Console.Write("Ingrese el radio del circulo: ");
            while (!int.TryParse(Console.ReadLine(), out primerNumero) || primerNumero <= 0)
            {
                Console.Clear();
                Console.Write("Error Ingrese el radio del circulo: ");
            }
            Console.Clear();
            Console.Write(CalculoArea.CalcularCirculo(primerNumero));
            Console.ReadLine();

           
        }
    }
}
