﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio14
{
    class CalculoArea
    {
        public static double CalcularCuadrado(double lado)
        {
            return lado * lado;
        }

        public static double CalcularTriangulo(double baseTriangulo, double altura)
        {
            return (altura * baseTriangulo)/2;
        }

        public static double CalcularCirculo(double radio)
        {
            return Math.Pow(Math.PI * radio, 2);
        }

    }
}
