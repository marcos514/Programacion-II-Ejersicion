﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio12
{
    class Program
    {
        static void Main(string[] args)
        {
            int sumador = 0;
            int numeroIngresado;
            do
            {
                Console.Write("Ingrese un numero");
                while (!int.TryParse(Console.ReadLine(), out numeroIngresado))
                {
                    Console.Clear();
                    Console.Write("Error ingrese un numero: ");
                }
                sumador += numeroIngresado;


                Console.WriteLine("Continuar? s/n");
            } while (ValidarRespuesta.ValidarS_N());

            Console.Clear();
            Console.WriteLine("Acumulador: "+sumador);
            Console.ReadLine();
        }
    }
}
