﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio12
{
    class ValidarRespuesta
    {
        public static bool ValidarS_N()
        {
            string caracter;
            
            caracter = Console.ReadLine();
            while (caracter != "s" && caracter != "n")
            {
                Console.Write("Error Reingrese s/n");
                caracter = Console.ReadLine();
            }
            return caracter == "s";
        }
    }
}
